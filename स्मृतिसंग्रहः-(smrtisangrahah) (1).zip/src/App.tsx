import React, { useState, useEffect } from 'react';
import { 
  Library, 
  BookOpen, 
  Users, 
  Plus, 
  Search, 
  LogOut, 
  ChevronRight, 
  Calendar, 
  UserPlus, 
  ArrowRightLeft, 
  Gift,
  CheckCircle2,
  Clock,
  Trash2,
  Edit3,
  X,
  Scroll,
  History,
  Bookmark,
  Compass,
  Download,
  Shield,
  LayoutDashboard,
  ArrowLeft,
  User as UserIcon,
  Camera
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import AIAssistant from './components/AIAssistant';
import { Book, Member, Demand, Transaction, GiftRecord, User } from './types';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import MemberPanel from './components/MemberPanel';
import AdminPanel from './components/AdminPanel';
import Navbar from './components/Navbar';
import LandingPage from './components/LandingPage';
import { formatAadhaar, formatMobile } from './utils/formatters';
import { getBookStatus } from './utils/libraryUtils';

// --- Utility Functions ---
// Removed local formatters as they are imported

// Removed local Navbar and LandingPage as they are imported

export default function App() {
  const [view, setView] = useState<'landing' | 'login' | 'signup' | 'admin' | 'member'>('landing');
  const [adminTab, setAdminTab] = useState<'dashboard' | 'books' | 'members' | 'approvals' | 'demands' | 'transactions' | 'categories' | 'gifting' | 'security'>('dashboard');
  const [memberTab, setMemberTab] = useState<'dashboard' | 'books' | 'demands'>('dashboard');
  const [user, setUser] = useState<User | null>(null);
  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [demands, setDemands] = useState<Demand[]>([]);
  const [memberDemands, setMemberDemands] = useState<Demand[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [gifts, setGifts] = useState<GiftRecord[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [bookSearchQuery, setBookSearchQuery] = useState('');
  const [memberSearchQuery, setMemberSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingType, setProcessingType] = useState<'login' | 'logout' | 'register' | 'delete' | 'update' | 'account' | 'gift' | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [lastError, setLastError] = useState<string | null>(null);
  
  // Forms
  const [loginForm, setLoginForm] = useState({ id: '', username: '', password: '', type: 'admin' });
  const [signupForm, setSignupForm] = useState<any>({ 
    name: '', 
    fatherName: '', 
    address: '', 
    aadhaar: '', 
    mobile: '', 
    email: '', 
    dob: '', 
    joiningDate: new Date().toISOString().split('T')[0],
    photo: null,
    password: ''
  });

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSignupForm({ ...signupForm, photo: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };
  const [isSignup, setIsSignup] = useState(false);
  const [securityForm, setSecurityForm] = useState({ username: '', password: '' });
  const [giftForm, setGiftForm] = useState({ bookId: '', memberId: '' });
  const [loginError, setLoginError] = useState('');
  const [bookForm, setBookForm] = useState<Partial<Book>>({});
  const [memberForm, setMemberForm] = useState<Partial<Member>>({
    joinedDate: new Date().toISOString().split('T')[0],
    dob: ''
  });
  const [issueForm, setIssueForm] = useState({ bookId: '', memberId: '', dueDate: '' });
  const [newCategory, setNewCategory] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'addBook' | 'editBook' | 'addMember' | 'editMember' | 'issueBook' | 'viewBill' | 'confirmDeleteBook' | 'confirmDeleteMember' | null>(null);
  const [selectedBill, setSelectedBill] = useState<string | null>(null);
  const [billBlobUrl, setBillBlobUrl] = useState<string | null>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  useEffect(() => {
    if (selectedBill && modalType === 'viewBill') {
      const createBlobUrl = async () => {
        try {
          const res = await fetch(selectedBill);
          const blob = await res.blob();
          const url = URL.createObjectURL(blob);
          setBillBlobUrl(url);
        } catch (error) {
          console.error('Error creating blob URL:', error);
          setBillBlobUrl(selectedBill);
        }
      };
      createBlobUrl();
    } else {
      if (billBlobUrl) {
        URL.revokeObjectURL(billBlobUrl);
        setBillBlobUrl(null);
      }
    }
    
    return () => {
      if (billBlobUrl) {
        URL.revokeObjectURL(billBlobUrl);
      }
    };
  }, [selectedBill, modalType]);

  useEffect(() => {
    const init = async () => {
      try {
        await checkAuth();
        await fetchCategories();
      } catch (error) {
        console.error('Initialization failed:', error);
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, []);

  const getBookStatus = (bookId: string) => {
    const book = books.find(b => b.id === bookId);
    if (book?.status === 'Gifted') return { label: 'Gifted [उपहारः]', color: 'text-purple-600', bg: 'bg-purple-50' };

    const bookTransactions = transactions.filter(t => t.bookId === bookId);
    if (bookTransactions.length === 0) return { label: 'In Catalog [संग्रहे अस्ति]', color: 'text-green-600', bg: 'bg-green-50' };
    
    const latest = [...bookTransactions].sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())[0];
    
    if (latest.returnDate) return { label: 'Returned [निवर्तितम्]', color: 'text-blue-600', bg: 'bg-blue-50' };
    
    const today = new Date().toISOString().split('T')[0];
    if (latest.dueDate < today) return { label: 'Overdue [कालातीतम्]', color: 'text-red-600', bg: 'bg-red-50' };
    
    return { label: 'Issued [निर्गमितम्]', color: 'text-orange-600', bg: 'bg-orange-50' };
  };

  const checkAuth = async () => {
    const token = localStorage.getItem('library_token');
    if (!token) {
      return;
    }

    try {
      const response = await fetch('/api/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        const userData: User = { 
          ...data.user, 
          isAdmin: data.user.isAdmin,
          role: data.user.isAdmin ? 'admin' : 'member'
        };
        setUser(userData);
        if (userData.isAdmin) {
          setView('admin');
          fetchAdminData();
        } else {
          setView('member');
          fetchMemberData();
        }
      } else {
        localStorage.removeItem('library_token');
      }
    } catch (error) {
      console.error('Auth check failed:', error);
    }
  };

  const triggerSuccess = async (message: string) => {
    setSuccessMessage(message);
    setShowSuccess(true);
    setLastError(null);
    await new Promise(resolve => setTimeout(resolve, 3000));
    setShowSuccess(false);
  };

  const triggerError = (message: string) => {
    setLastError(message);
    alert(message);
  };

  const simulateProcessing = async (type: typeof processingType, callback: () => Promise<void> | void) => {
    setIsProcessing(true);
    setProcessingType(type);
    const startTime = Date.now();
    try {
      await callback();
    } finally {
      const elapsedTime = Date.now() - startTime;
      const remainingTime = Math.max(0, 2500 - elapsedTime);
      setTimeout(() => {
        setIsProcessing(false);
        setProcessingType(null);
      }, remainingTime);
    }
  };

  const handleDeleteMember = async () => {
    if (!itemToDelete) return;
    const token = localStorage.getItem('library_token');
    simulateProcessing('delete', async () => {
      try {
        const response = await fetch(`/api/members/${encodeURIComponent(itemToDelete)}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.ok) {
          await fetchAdminData();
          setIsModalOpen(false);
          setItemToDelete(null);
          await triggerSuccess('Member record removed successfully.');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to delete member'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error deleting member:', error);
        triggerError('An unexpected error occurred while deleting the member.');
      }
    });
  };

  const fetchCategories = async () => {
    const token = localStorage.getItem('library_token');
    try {
      const headers: any = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;
      
      const response = await fetch('/api/categories', { headers });
      if (response.ok) {
        const data = await response.json();
        setCategories(data);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchAdminData = async () => {
    const token = localStorage.getItem('library_token');
    if (!token) return;

    try {
      const [booksRes, membersRes, transRes, catRes, giftRes, demandsRes] = await Promise.all([
        fetch('/api/books', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/admin/members', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/transactions', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/categories', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/gifts', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/admin/demands', { headers: { 'Authorization': `Bearer ${token}` } })
      ]);

      if (booksRes.ok) setBooks(await booksRes.json());
      if (membersRes.ok) setMembers(await membersRes.json());
      if (transRes.ok) setTransactions(await transRes.json());
      if (catRes.ok) setCategories(await catRes.json());
      if (giftRes.ok) setGifts(await giftRes.json());
      if (demandsRes.ok) setDemands(await demandsRes.json());
    } catch (error) {
      console.error('Error fetching admin data:', error);
    }
  };

  const fetchMemberData = async () => {
    const token = localStorage.getItem('library_token');
    if (!token) return;

    try {
      const [booksRes, catRes, demandsRes] = await Promise.all([
        fetch('/api/books', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/categories', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/api/member/demands', { headers: { 'Authorization': `Bearer ${token}` } })
      ]);

      if (booksRes.ok) setBooks(await booksRes.json());
      if (catRes.ok) setCategories(await catRes.json());
      if (demandsRes.ok) setMemberDemands(await demandsRes.json());
    } catch (error) {
      console.error('Error fetching member data:', error);
    }
  };

  const handleUpdateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('library_token');
    if (!token) return;

    simulateProcessing('account', async () => {
      try {
        const response = await fetch('/api/admin/account', {
          method: 'PUT',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(securityForm),
        });
        if (response.ok) {
          await triggerSuccess('Account security updated successfully!');
          setSecurityForm({ username: '', password: '' });
        } else {
          triggerError('Failed to update account security');
        }
      } catch (error) {
        console.error('Error updating account:', error);
      }
    });
  };

  const handleGiftBook = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('library_token');
    if (!token) return;

    simulateProcessing('gift', async () => {
      try {
        const response = await fetch('/api/gift', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(giftForm),
        });
        if (response.ok) {
          await fetchAdminData();
          await triggerSuccess('Book gifted successfully for life!');
          setGiftForm({ bookId: '', memberId: '' });
        } else {
          const data = await response.json();
          triggerError(data.error || 'Failed to gift book');
        }
      } catch (error) {
        console.error('Error gifting book:', error);
      }
    });
  };

  const exportInventoryPDF = () => {
    const doc = new jsPDF();
    const date = new Date().toLocaleDateString();
    
    doc.setFontSize(20);
    doc.text("Smriti Sangrah Library - Inventory Report", 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${date}`, 14, 30);
    doc.text(`Total Books: ${books.length}`, 14, 38);

    const tableData = books.map(book => [
      book.id,
      book.title,
      book.author,
      book.category,
      book.year,
      book.status
    ]);

    autoTable(doc, {
      startY: 45,
      head: [['ID', 'Title', 'Author', 'Category', 'Year', 'Status']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [44, 30, 18] }
    });

    doc.save(`library_inventory_${date}.pdf`);
  };

  const exportMembersPDF = () => {
    const doc = new jsPDF();
    const date = new Date().toLocaleDateString();
    
    doc.setFontSize(20);
    doc.text("Smriti Sangrah Library - Members Report", 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${date}`, 14, 30);
    doc.text(`Total Members: ${members.length}`, 14, 38);

    const tableData = members.map(member => [
      member.id,
      member.name,
      member.mobile,
      member.email,
      member.joinedDate
    ]);

    autoTable(doc, {
      startY: 45,
      head: [['ID', 'Name', 'Mobile', 'Email', 'Joined Date']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [44, 30, 18] }
    });

    doc.save(`library_members_${date}.pdf`);
  };

  const exportCirculationPDF = () => {
    const doc = new jsPDF();
    const date = new Date().toLocaleDateString();
    
    doc.setFontSize(20);
    doc.text("Smriti Sangrah Library - Circulation Report", 14, 22);
    doc.setFontSize(11);
    doc.text(`Generated on: ${date}`, 14, 30);
    doc.text(`Total Transactions: ${transactions.length}`, 14, 38);

    const tableData = transactions.map(t => [
      t.id,
      t.book?.title || t.bookId,
      t.member?.name || t.memberId,
      t.issueDate,
      t.dueDate,
      t.returnDate || 'Not Returned'
    ]);

    autoTable(doc, {
      startY: 45,
      head: [['ID', 'Book', 'Member', 'Issue Date', 'Due Date', 'Return Date']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [44, 30, 18] }
    });

    doc.save(`library_circulation_${date}.pdf`);
  };

  const handleApproveMember = async (memberId: string) => {
    setIsProcessing(true);
    setProcessingType('update');
    try {
      const res = await fetch('/api/admin/approve-member', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('library_token')}`
        },
        body: JSON.stringify({ memberId })
      });
      if (res.ok) {
        await triggerSuccess(`Member approved successfully!`);
        await fetchAdminData();
      } else {
        const err = await res.json();
        triggerError(err.error || 'Approval failed');
        setLastError(err.error || 'Approval failed');
      }
    } catch (error) {
      setLastError('Connection error');
    } finally {
      setIsProcessing(false);
      setProcessingType(null);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    simulateProcessing('login', async () => {
      try {
        const response = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(loginForm),
        });
        if (response.ok) {
          const data = await response.json();
          localStorage.setItem('library_token', data.token);
          const userData: User = { 
            ...data.user, 
            isAdmin: data.user.isAdmin,
            role: data.user.isAdmin ? 'admin' : 'member'
          };
          setUser(userData);
          if (userData.isAdmin) {
            setView('admin');
            fetchAdminData();
          } else {
            setView('member');
            fetchMemberData();
          }
          triggerSuccess('Login Successful! Welcome to Smrtisangrahah.');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            setLoginError(errorData.error || 'Invalid credentials');
          } else {
            setLoginError(`Login failed: ${response.status} ${response.statusText}`);
          }
        }
      } catch (error) {
        setLoginError('An unexpected error occurred during login');
        console.error('Login error:', error);
      }
    });
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    simulateProcessing('register', async () => {
      try {
        const response = await fetch('/api/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(signupForm),
        });
        if (response.ok) {
          const data = await response.json();
          triggerSuccess(`Registration successful! Member ID: ${data.memberId}. Please wait for admin approval.`);
          setView('landing');
          setSignupForm({ 
            name: '', 
            fatherName: '', 
            address: '', 
            aadhaar: '', 
            mobile: '', 
            email: '', 
            dob: '', 
            joiningDate: new Date().toISOString().split('T')[0],
            photo: null,
            password: ''
          });
        } else {
          const errorData = await response.json();
          triggerError(errorData.error || 'Signup failed');
        }
      } catch (error) {
        triggerError('An unexpected error occurred during signup');
      }
    });
  };

  const handleDemandBook = async (bookId: string) => {
    const token = localStorage.getItem('library_token');
    if (!token) return;

    simulateProcessing('register', async () => {
      try {
        const response = await fetch('/api/member/demand', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ bookId }),
        });
        if (response.ok) {
          await fetchMemberData();
          await triggerSuccess('Book requested successfully!');
        } else {
          const data = await response.json();
          triggerError(data.error || 'Failed to request book');
        }
      } catch (error) {
        console.error('Error demanding book:', error);
      }
    });
  };

  const handleUndemandBook = async (demandId: string) => {
    const token = localStorage.getItem('library_token');
    if (!token) return;

    simulateProcessing('delete', async () => {
      try {
        const response = await fetch('/api/member/undemand', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ demandId }),
        });
        if (response.ok) {
          await fetchMemberData();
          await triggerSuccess('Request cancelled successfully.');
        } else {
          const data = await response.json();
          triggerError(data.error || 'Failed to cancel request');
        }
      } catch (error) {
        console.error('Error undemanding book:', error);
      }
    });
  };

  const handleApproveDemand = async (demandId: string) => {
    const token = localStorage.getItem('library_token');
    if (!token) return;

    simulateProcessing('update', async () => {
      try {
        const response = await fetch('/api/admin/approve-demand', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ demandId }),
        });
        if (response.ok) {
          await fetchAdminData();
          await triggerSuccess('Demand approved and volume issued!');
        } else {
          const data = await response.json();
          triggerError(data.error || 'Failed to approve demand');
        }
      } catch (error) {
        console.error('Error approving demand:', error);
      }
    });
  };
  const handleLogout = () => {
    simulateProcessing('logout', () => {
      localStorage.removeItem('library_token');
      setUser(null);
      setView('landing');
      triggerSuccess('Logged out successfully.');
    });
  };

  // --- Admin Actions ---
  const handleAddBook = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('library_token');
    if (!token) return;
    
    simulateProcessing('register', async () => {
      try {
        const isEdit = modalType === 'editBook';
        const method = isEdit ? 'PUT' : 'POST';
        const url = isEdit ? `/api/books/${encodeURIComponent(bookForm.id)}` : '/api/books';
        
        const response = await fetch(url, {
          method,
          headers: { 
            'Content-Type': 'application/json', 
            'Authorization': `Bearer ${token}` 
          },
          body: JSON.stringify(bookForm),
        });

        if (response.ok) {
          await fetchAdminData();
          setIsModalOpen(false);
          setBookForm({});
          await triggerSuccess(isEdit ? 'Book details updated successfully!' : 'New book registered successfully!');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to save book'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error saving book:', error);
        triggerError('An unexpected error occurred while saving the book.');
      }
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      triggerError('Please upload a PDF file.');
      return;
    }

    if (file.size > 200 * 1024) {
      triggerError('File size must be under 200 KB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setBookForm({ ...bookForm, billData: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('library_token');
    simulateProcessing('register', async () => {
      try {
        const response = await fetch('/api/categories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify({ name: newCategory }),
        });
        if (response.ok) {
          await fetchAdminData();
          setNewCategory('');
          await triggerSuccess('Category added successfully!');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to add category'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error adding category:', error);
        triggerError('An unexpected error occurred while adding the category.');
      }
    });
  };

  const handleDeleteCategory = async (name: string) => {
    const token = localStorage.getItem('library_token');
    simulateProcessing('delete', async () => {
      try {
        const response = await fetch(`/api/categories/${encodeURIComponent(name)}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.ok) {
          await fetchAdminData();
          await triggerSuccess('Category removed successfully.');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to delete category'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error deleting category:', error);
        triggerError('An unexpected error occurred while deleting the category.');
      }
    });
  };

  const handleMemberPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      triggerError('Please upload an image file.');
      return;
    }

    if (file.size > 50 * 1024) {
      triggerError('Photo size must be under 50 KB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setMemberForm({ ...memberForm, photo: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const generateIDCard = (member: Member) => {
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: [85.6, 54] // ID-1 standard size
    });

    // Background
    doc.setFillColor(249, 247, 242);
    doc.rect(0, 0, 85.6, 54, 'F');

    // Header
    doc.setFillColor(44, 30, 18);
    doc.rect(0, 0, 85.6, 12, 'F');
    doc.setTextColor(212, 175, 55);
    doc.setFontSize(14);
    doc.text('SMRTISANGRAHAH', 42.8, 8, { align: 'center' });

    // Photo
    if (member.photo) {
      // Draw a circular border first
      doc.setDrawColor(212, 175, 55);
      doc.setLineWidth(0.8);
      doc.circle(15, 28, 11, 'S');
      
      // Clipping for circular photo
      // Note: jsPDF clipping can be complex, using a simpler approach with a circle mask if needed
      // but standard clip() works in most modern versions
      doc.saveGraphicsState();
      doc.circle(15, 28, 10.5, 'F');
      doc.clip();
      // Zoomed in effect: draw image slightly larger than the circle
      doc.addImage(member.photo, 'JPEG', 3, 16, 24, 24); 
      doc.restoreGraphicsState();
    } else {
      doc.setDrawColor(139, 69, 19);
      doc.setLineWidth(0.5);
      doc.circle(15, 28, 10, 'S');
      doc.setTextColor(139, 69, 19);
      doc.setFontSize(6);
      doc.text('NO PHOTO', 15, 29, { align: 'center' });
    }

    // Member Info
    doc.setTextColor(44, 30, 18);
    doc.setFontSize(10);
    doc.text(member.name, 30, 18);
    
    doc.setFontSize(7);
    doc.setTextColor(139, 69, 19);
    doc.text(`ID: ${member.id}`, 30, 22);
    doc.text(`Father: ${member.fatherName}`, 30, 26);
    doc.text(`DOB: ${member.dob}`, 30, 30);
    doc.text(`Mobile: ${member.mobile}`, 30, 34);
    doc.text(`Aadhaar: ${member.aadhaar}`, 30, 38);
    doc.text(`Email: ${member.email}`, 30, 42);
    
    doc.setFontSize(6);
    doc.text(`Address: ${member.address}`, 30, 46, { maxWidth: 50 });

    // Footer
    doc.setFillColor(212, 175, 55);
    doc.rect(0, 50, 85.6, 4, 'F');
    doc.setTextColor(44, 30, 18);
    doc.setFontSize(6);
    doc.text(`Joined: ${member.joinedDate}`, 42.8, 53, { align: 'center' });

    doc.save(`ID_Card_${member.id.replace(/\//g, '_')}.pdf`);
  };

  const resetMemberForm = () => {
    setMemberForm({
      joinedDate: new Date().toISOString().split('T')[0],
      dob: '',
      photo: null
    });
  };

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('library_token');
    simulateProcessing('register', async () => {
      try {
        const response = await fetch('/api/members', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify(memberForm),
        });
        if (response.ok) {
          await fetchAdminData();
          setIsModalOpen(false);
          resetMemberForm();
          await triggerSuccess('New member registered successfully!');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to add member'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error adding member:', error);
        triggerError('An unexpected error occurred while adding the member.');
      }
    });
  };

  const handleEditMember = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('library_token');
    simulateProcessing('update', async () => {
      try {
        const response = await fetch(`/api/members/${encodeURIComponent(memberForm.id || '')}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify(memberForm),
        });
        if (response.ok) {
          await fetchAdminData();
          setIsModalOpen(false);
          resetMemberForm();
          await triggerSuccess('Member details updated successfully!');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to update member'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error updating member:', error);
        triggerError('An unexpected error occurred while updating the member.');
      }
    });
  };

  const handleIssueBook = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('library_token');
    simulateProcessing('register', async () => {
      try {
        const response = await fetch('/api/issue', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
          body: JSON.stringify(issueForm),
        });
        if (response.ok) {
          await fetchAdminData();
          setIsModalOpen(false);
          setIssueForm({ bookId: '', memberId: '', dueDate: '' });
          await triggerSuccess('Volume issued successfully!');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to issue book'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error issuing book:', error);
        triggerError('An unexpected error occurred while issuing the book.');
      }
    });
  };

  const handleReceiveBook = async (transactionId: string) => {
    const token = localStorage.getItem('library_token');
    simulateProcessing('update', async () => {
      try {
        const response = await fetch(`/api/receive/${transactionId}`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (response.ok) {
          await fetchAdminData();
          await triggerSuccess('Volume received and catalog updated!');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to receive book'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error receiving book:', error);
        triggerError('An unexpected error occurred while receiving the book.');
      }
    });
  };

  const handleDeleteBook = async () => {
    if (!itemToDelete) return;
    const token = localStorage.getItem('library_token');
    simulateProcessing('delete', async () => {
      try {
        const response = await fetch(`/api/books/${encodeURIComponent(itemToDelete)}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.ok) {
          await fetchAdminData();
          setIsModalOpen(false);
          setItemToDelete(null);
          await triggerSuccess('Book record removed successfully.');
        } else {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorData = await response.json();
            triggerError(`Error: ${errorData.error || 'Failed to delete book'}`);
          } else {
            const errorText = await response.text();
            triggerError(`Error: ${response.status} ${response.statusText}${errorText ? ' - ' + errorText : ''}`);
          }
        }
      } catch (error) {
        console.error('Error deleting book:', error);
        triggerError('An unexpected error occurred while deleting the book.');
      }
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#2c1e12] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#d4af37]"></div>
      </div>
    );
  }

  // --- Components ---

  const LoginPage = ({ loginForm, setLoginForm, handleLogin, loginError, isProcessing, setView }: any) => (
  <div className="min-h-screen bg-[#2c1e12] flex items-center justify-center px-6 relative overflow-hidden">
    <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/dark-leather.png')]" />
    
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-lg relative z-10"
    >
      <div className="bg-[#f5f2ed] p-10 rounded-lg shadow-[0_20px_50px_rgba(0,0,0,0.5)] border-t-8 border-[#d4af37]">
        <div className="text-center mb-10">
          <Shield className="w-12 h-12 text-[#8b4513] mx-auto mb-6" />
          <h2 className="text-3xl font-serif font-bold text-[#2c1e12] mb-2">प्रवेशः [Login]</h2>
          <p className="text-[#8b4513] text-[10px] uppercase tracking-[0.2em] font-sans font-bold">Access the Smrtisangrahah Portal</p>
        </div>

        <div className="flex gap-4 mb-8">
          <button 
            onClick={() => setLoginForm({ ...loginForm, type: 'admin' })}
            className={`flex-1 py-3 text-[10px] uppercase tracking-widest font-bold transition-all ${loginForm.type === 'admin' ? 'bg-[#2c1e12] text-[#d4af37]' : 'bg-white text-[#2c1e12] border border-[#2c1e12]/10 hover:bg-[#2c1e12]/5'}`}
          >
            प्रबन्धकः (Admin)
          </button>
          <button 
            onClick={() => setLoginForm({ ...loginForm, type: 'member' })}
            className={`flex-1 py-3 text-[10px] uppercase tracking-widest font-bold transition-all ${loginForm.type === 'member' ? 'bg-[#2c1e12] text-[#d4af37]' : 'bg-white text-[#2c1e12] border border-[#2c1e12]/10 hover:bg-[#2c1e12]/5'}`}
          >
            सदस्यः (Member)
          </button>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-[#5d4037] text-[10px] uppercase tracking-[0.2em] font-sans font-bold mb-2">
              {loginForm.type === 'admin' ? 'प्रयोक्तृनाम [Username]' : 'सदस्य ID [Member ID]'}
            </label>
            <input 
              type="text" required
              className="w-full bg-white border-2 border-[#8b4513]/20 px-4 py-3 text-[#2c1e12] focus:outline-none focus:border-[#d4af37] transition-colors font-serif"
              value={loginForm.username}
              onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-[#5d4037] text-[10px] uppercase tracking-[0.2em] font-sans font-bold mb-2">कूटशब्दः [Password]</label>
            <input 
              type="password" required
              className="w-full bg-white border-2 border-[#8b4513]/20 px-4 py-3 text-[#2c1e12] focus:outline-none focus:border-[#d4af37] transition-colors font-serif"
              value={loginForm.password}
              onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
            />
          </div>
          
          {loginError && <p className="text-red-600 text-xs text-center font-bold">{loginError}</p>}

          <button 
            type="submit" disabled={isProcessing}
            className="w-full bg-[#2c1e12] text-[#d4af37] py-4 rounded-sm font-bold uppercase tracking-[0.3em] text-xs hover:bg-[#3d2a1a] transition-all duration-300 flex items-center justify-center gap-3"
          >
            {isProcessing ? (
              <div className="w-4 h-4 border-2 border-[#d4af37] border-t-transparent animate-spin rounded-full" />
            ) : (
              <>प्रविशतु [Enter] <ArrowRightLeft className="w-4 h-4" /></>
            )}
          </button>
        </form>

        <div className="mt-10 pt-8 border-t border-[#8b4513]/10 text-center">
          <p className="text-[#5d4037] text-sm mb-4 italic">Not a member yet?</p>
          <button 
            onClick={() => setView('signup')}
            className="text-[#8b4513] text-[10px] uppercase tracking-widest font-bold border-b-2 border-[#8b4513]/20 hover:border-[#d4af37] hover:text-[#d4af37] transition-all"
          >
            सदस्यतायै पञ्जीकरणम् [Register for Membership]
          </button>
        </div>
      </div>
    </motion.div>
  </div>
);

const SignupPage = ({ signupForm, setSignupForm, handleSignup, handlePhotoChange, setView }: any) => {
  return (
    <div className="min-h-screen bg-[#f5f2ed] flex items-center justify-center p-6 font-serif bg-[url('https://www.transparenttextures.com/patterns/paper-fibers.png')]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white w-full max-w-4xl shadow-[0_30px_100px_rgba(0,0,0,0.12)] border border-[#8b4513]/10 overflow-hidden rounded-sm"
      >
        <div className="grid grid-cols-1 md:grid-cols-5 h-full">
          <div className="md:col-span-2 bg-[#2c1e12] p-12 text-[#d4af37] flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
              <Scroll className="w-96 h-96 -translate-x-20 -translate-y-20 rotate-12" />
            </div>
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-12">
                <div className="p-3 bg-[#d4af37]/10 rounded-sm border border-[#d4af37]/30">
                  <Scroll className="w-8 h-8 text-[#d4af37]" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[#f5f2ed] font-serif font-bold tracking-wider text-2xl leading-tight">स्मृतिसंग्रहः</span>
                  <span className="text-[#d4af37] text-[10px] uppercase tracking-[0.2em] font-medium">Smrtisangrahah</span>
                </div>
              </div>
              <h2 className="text-4xl font-bold mb-6 leading-tight text-[#f5f2ed]">Join the Sanctuary of Wisdom</h2>
              <p className="text-[#d4af37]/80 text-sm leading-relaxed italic">
                "ज्ञानं परमं बलम्" — Knowledge is the ultimate strength. Register to access our vast collection of ancient and modern wisdom.
              </p>
            </div>
            <div className="relative z-10 mt-12">
              <p className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-40 mb-4">Already a member?</p>
              <button 
                onClick={() => setView('login')}
                className="flex items-center gap-3 text-sm font-bold hover:text-[#f5f2ed] transition-colors group"
              >
                <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                Back to Login
              </button>
            </div>
          </div>

          <div className="md:col-span-3 p-12 overflow-y-auto max-h-[90vh]">
            <div className="mb-10">
              <h3 className="text-2xl font-bold text-[#2c1e12] mb-2">Member Registration</h3>
              <p className="text-[#8b4513]/60 text-xs uppercase tracking-widest font-bold">Please provide your authentic details</p>
            </div>

            <form onSubmit={handleSignup} className="space-y-8">
              <div className="flex flex-col items-center mb-8">
                <div className="relative group">
                  <div className="w-32 h-32 rounded-full border-4 border-[#d4af37]/20 overflow-hidden bg-[#f9f7f2] flex items-center justify-center relative transition-all group-hover:border-[#d4af37]/50">
                    {signupForm.photo ? (
                      <img src={signupForm.photo} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <UserIcon className="w-12 h-12 text-[#8b4513]/20" />
                    )}
                    <label className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                      <Camera className="w-6 h-6 text-white" />
                      <input type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
                    </label>
                  </div>
                  <p className="text-[10px] uppercase tracking-widest text-[#8b4513]/60 font-bold mt-3 text-center">Upload Member Photo</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Full Name [पूर्ण नाम]</label>
                  <input 
                    type="text" 
                    required 
                    className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                    value={signupForm.name}
                    onChange={(e) => setSignupForm({ ...signupForm, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Father's Name [पितुः नाम]</label>
                  <input 
                    type="text" 
                    required 
                    className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                    value={signupForm.fatherName}
                    onChange={(e) => setSignupForm({ ...signupForm, fatherName: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Email ID [ईमेल]</label>
                  <input 
                    type="email" 
                    required 
                    className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                    value={signupForm.email}
                    onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Mobile Number [दूरभाषः]</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="+91 - XXXXXXXXXX"
                    className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                    value={signupForm.mobile}
                    onChange={(e) => setSignupForm({ ...signupForm, mobile: formatMobile(e.target.value) })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Date of Birth [जन्मदिनाङ्कः]</label>
                  <input 
                    type="date" 
                    required 
                    className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                    value={signupForm.dob}
                    onChange={(e) => setSignupForm({ ...signupForm, dob: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Joining Date [प्रवेश दिनाङ्कः]</label>
                  <input 
                    type="date" 
                    required 
                    className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                    value={signupForm.joiningDate}
                    onChange={(e) => setSignupForm({ ...signupForm, joiningDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Aadhaar Number [आधार सङ्ख्या]</label>
                <input 
                  type="text" 
                  required 
                  placeholder="XXXX - XXXX - XXXX"
                  className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                  value={signupForm.aadhaar}
                  onChange={(e) => setSignupForm({ ...signupForm, aadhaar: formatAadhaar(e.target.value) })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Full Address [पूर्णं सङ्केतः]</label>
                <textarea 
                  required 
                  rows={3}
                  className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans resize-none"
                  value={signupForm.address}
                  onChange={(e) => setSignupForm({ ...signupForm, address: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Set Password [कूटशब्दः]</label>
                <input 
                  type="password" 
                  required 
                  className="w-full bg-[#f9f7f2] border-b-2 border-[#8b4513]/10 px-0 py-3 focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                  value={signupForm.password}
                  onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                />
              </div>

              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit" 
                className="w-full bg-[#2c1e12] text-[#d4af37] py-5 rounded-sm text-xs uppercase font-bold tracking-[0.3em] shadow-xl hover:bg-[#3d2b1a] transition-all border border-[#d4af37]/20 mt-10"
              >
                Request Membership [सदस्यतायै प्रार्थना]
              </motion.button>
            </form>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

  const MemberPanel = ({ user, memberTab, setMemberTab, handleLogout, books, handleDemandBook, memberDemands }: any) => (
  <div className="min-h-screen bg-[#fdfaf5] flex font-serif text-[#1a120b]">
    {/* Sidebar Navigation */}
    <aside className="w-80 bg-[#1a120b] text-[#d4af37] flex flex-col h-screen sticky top-0 overflow-y-auto shadow-2xl z-20 border-r border-[#d4af37]/10">
      <div className="p-10 border-b border-[#d4af37]/10">
        <div className="flex items-center gap-4 mb-8">
          <div className="p-3 bg-[#d4af37]/5 rounded-sm border border-[#d4af37]/20">
            <Scroll className="w-8 h-8 text-[#d4af37]" />
          </div>
          <div className="flex flex-col">
            <span className="text-[#fdfaf5] font-serif font-bold tracking-wider text-2xl leading-tight">स्मृतिसंग्रहः</span>
            <span className="text-[#d4af37] text-[10px] uppercase tracking-[0.3em] font-medium opacity-70">Smrtisangrahah</span>
          </div>
        </div>
        <div className="mt-10 p-5 bg-[#d4af37]/5 border border-[#d4af37]/10 rounded-sm">
          <p className="text-[#fdfaf5] font-bold text-sm mb-1">{user?.name}</p>
          <p className="text-[#d4af37]/50 text-[9px] uppercase tracking-[0.2em] font-sans font-bold">Respected Member</p>
        </div>
      </div>

      <nav className="flex-1 p-6 space-y-2 mt-6">
        {[
          { id: 'dashboard', label: 'Dashboard [फलकम्]', icon: LayoutDashboard },
          { id: 'books', label: 'Books [ग्रन्थाः]', icon: BookOpen },
          { id: 'demands', label: 'My Requests [प्रार्थनाः]', icon: Clock },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setMemberTab(tab.id as any)}
            className={`w-full flex items-center gap-5 px-6 py-4.5 transition-all rounded-sm group relative ${
              memberTab === tab.id 
                ? 'bg-[#d4af37] text-[#1a120b] shadow-[0_10px_20px_rgba(212,175,55,0.15)]' 
                : 'hover:bg-[#d4af37]/5 text-[#d4af37]/40 hover:text-[#d4af37]'
            }`}
          >
            <tab.icon className={`w-5 h-5 ${memberTab === tab.id ? 'text-[#1a120b]' : 'group-hover:text-[#d4af37]'}`} />
            <span className="text-[11px] uppercase tracking-[0.15em] font-bold font-sans">{tab.label}</span>
            {memberTab === tab.id && (
              <motion.div 
                layoutId="activeMemberTab"
                className="absolute left-0 top-0 h-full w-1 bg-[#1a120b]/20" 
              />
            )}
          </button>
        ))}
      </nav>

      <div className="p-8 border-t border-[#d4af37]/10 bg-[#0d0905]">
        <button 
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-3 bg-transparent text-[#d4af37]/60 px-6 py-4 rounded-sm text-[10px] uppercase tracking-widest font-bold hover:bg-[#d4af37] hover:text-[#1a120b] transition-all border border-[#d4af37]/20"
        >
          <LogOut className="w-4 h-4" />
          निर्गमनम् (Logout)
        </button>
      </div>
    </aside>

    {/* Main Content Area */}
    <main className="flex-1 p-12 overflow-y-auto bg-[url('https://www.transparenttextures.com/patterns/paper-fibers.png')]">
      <div className="max-w-7xl mx-auto">
        {memberTab === 'dashboard' && (
          <div className="space-y-12">
            <div className="flex justify-between items-end border-b-2 border-[#d4af37]/20 pb-8">
              <div>
                <h1 className="text-5xl font-serif font-bold text-[#2c1e12] mb-3">स्वागतम् [Welcome]</h1>
                <p className="text-[#8b4513] text-[10px] uppercase tracking-[0.3em] font-sans font-bold">Explore the Sanctuary of Wisdom</p>
              </div>
              <div className="text-right">
                <p className="text-[#2c1e12] font-bold text-xl">{new Date().toLocaleDateString('sa-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                <p className="text-[#8b4513]/60 text-[10px] uppercase tracking-widest font-sans font-bold">Current Date</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-sm shadow-sm border-l-4 border-[#d4af37]">
                <p className="text-[#8b4513]/60 text-[10px] uppercase tracking-widest font-bold mb-2">My ID</p>
                <p className="text-2xl font-bold text-[#2c1e12]">{user?.id}</p>
              </div>
              <div className="bg-white p-8 rounded-sm shadow-sm border-l-4 border-[#556b2f]">
                <p className="text-[#8b4513]/60 text-[10px] uppercase tracking-widest font-bold mb-2">Status</p>
                <p className="text-2xl font-bold text-[#556b2f] uppercase tracking-widest">{user?.status}</p>
              </div>
              <div className="bg-white p-8 rounded-sm shadow-sm border-l-4 border-[#8b4513]">
                <p className="text-[#8b4513]/60 text-[10px] uppercase tracking-widest font-bold mb-2">Joined</p>
                <p className="text-2xl font-bold text-[#2c1e12]">{user?.joinedDate}</p>
              </div>
            </div>
          </div>
        )}

        {memberTab === 'books' && (
          <div className="space-y-10">
            <div className="flex justify-between items-center">
              <h2 className="text-4xl font-serif font-bold text-[#2c1e12]">ग्रन्थ सूची [Book Collection]</h2>
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b4513]/40" />
                  <input 
                    type="text" 
                    placeholder="Search books..."
                    className="bg-white border-2 border-[#8b4513]/10 pl-12 pr-6 py-3 text-sm focus:outline-none focus:border-[#d4af37] transition-all w-80"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {books.map((book: any) => (
                <motion.div 
                  key={book.id}
                  whileHover={{ y: -5 }}
                  className="bg-white p-8 rounded-sm shadow-sm border border-[#8b4513]/10 relative group"
                >
                  <div className="absolute top-4 right-4">
                    <span className={`text-[9px] uppercase font-bold tracking-widest px-3 py-1 rounded-full ${
                      book.status === 'Available' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                    }`}>
                      {book.status}
                    </span>
                  </div>
                  <BookOpen className="w-10 h-10 text-[#d4af37] mb-6 opacity-40" />
                  <h3 className="text-xl font-bold text-[#2c1e12] mb-2 line-clamp-1">{book.title}</h3>
                  <p className="text-[#8b4513] text-sm mb-4 italic">by {book.author}</p>
                  <div className="flex justify-between items-center pt-6 border-t border-[#8b4513]/5">
                    <span className="text-[10px] uppercase tracking-widest text-[#8b4513]/60 font-bold">{book.category}</span>
                    {book.status === 'Available' && (
                      <button 
                        onClick={() => handleDemandBook(book.id)}
                        className="text-[10px] uppercase tracking-widest font-bold text-[#2c1e12] hover:text-[#d4af37] transition-colors"
                      >
                        Request [प्रार्थयतु]
                      </button>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {memberTab === 'demands' && (
          <div className="space-y-10">
            <h2 className="text-4xl font-serif font-bold text-[#2c1e12]">मम प्रार्थनाः [My Requests]</h2>
            <div className="bg-white rounded-sm shadow-sm overflow-hidden border border-[#8b4513]/10">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#f9f7f2] border-b border-[#8b4513]/10">
                    <th className="p-6 text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Book [ग्रन्थः]</th>
                    <th className="p-6 text-[10px] uppercase tracking-widest text-[#8b4513] font-bold">Date [दिनाङ्कः]</th>
                    <th className="p-6 text-[10px] uppercase tracking-widest text-[#8b4513] font-bold text-right">Status [स्थितिः]</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#8b4513]/5">
                  {memberDemands.map((demand: any) => (
                    <tr key={demand.id} className="hover:bg-[#f9f7f2]/50 transition-colors">
                      <td className="p-6">
                        <div className="font-bold text-[#2c1e12]">{demand.bookTitle}</div>
                        <div className="text-[10px] text-[#8b4513]/60 uppercase tracking-widest">ID: {demand.bookId}</div>
                      </td>
                      <td className="p-6 text-sm text-[#5d4037]">{demand.requestDate}</td>
                      <td className="p-6 text-right">
                        <span className={`text-[9px] uppercase font-bold tracking-widest px-4 py-1.5 rounded-full ${
                          demand.status === 'pending' ? 'bg-amber-50 text-amber-700' : 'bg-green-50 text-green-700'
                        }`}>
                          {demand.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {memberDemands.length === 0 && (
                    <tr>
                      <td colSpan={3} className="p-20 text-center text-[#8b4513]/40 italic">
                        No requests found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </main>
  </div>
);

  const AdminPanel = () => (
    <div className="min-h-screen bg-[#fdfaf5] flex font-serif">
      {/* Sidebar Navigation */}
      <aside className="w-80 bg-[#1a120b] text-[#d4af37] flex flex-col h-screen sticky top-0 overflow-y-auto shadow-2xl z-20 border-r border-[#d4af37]/10">
        <div className="p-10 border-b border-[#d4af37]/10">
          <div className="flex items-center gap-4 mb-8">
            <div className="p-3 bg-[#d4af37]/5 rounded-sm border border-[#d4af37]/20">
              <Scroll className="w-8 h-8 text-[#d4af37]" />
            </div>
            <div className="flex flex-col">
              <span className="text-[#fdfaf5] font-serif font-bold tracking-wider text-2xl leading-tight">स्मृतिसंग्रहः</span>
              <span className="text-[#d4af37] text-[10px] uppercase tracking-[0.3em] font-medium opacity-70">Smrtisangrahah</span>
            </div>
          </div>
          <div className="mt-10 p-5 bg-[#d4af37]/5 border border-[#d4af37]/10 rounded-sm">
            <p className="text-[#fdfaf5] font-bold text-sm mb-1">{user?.username}</p>
            <p className="text-[#d4af37]/50 text-[9px] uppercase tracking-[0.2em] font-sans font-bold">Authorized Librarian</p>
          </div>
        </div>

        <nav className="flex-1 p-6 space-y-2 mt-6">
          {[
            { id: 'dashboard', label: 'मुख्यपृष्ठम् [Dashboard]', icon: LayoutDashboard },
            { id: 'books', label: 'सूची [Inventory]', icon: BookOpen },
            { id: 'members', label: 'सदस्याः [Members]', icon: Users },
            { id: 'approvals', label: 'अनुमोदनम् [Approvals]', icon: CheckCircle2 },
            { id: 'transactions', label: 'विनिमयः [Circulation]', icon: ArrowRightLeft },
            { id: 'categories', label: 'वर्गाः [Categories]', icon: Bookmark },
            { id: 'gifting', label: 'उपहारः [Gifting]', icon: Gift },
            { id: 'security', label: 'सुरक्षा [Security]', icon: Shield },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setAdminTab(tab.id as any)}
              className={`w-full flex items-center gap-5 px-6 py-4.5 transition-all rounded-sm group relative ${
                adminTab === tab.id 
                  ? 'bg-[#d4af37] text-[#1a120b] shadow-[0_10px_20px_rgba(212,175,55,0.15)]' 
                  : 'hover:bg-[#d4af37]/5 text-[#d4af37]/40 hover:text-[#d4af37]'
              }`}
            >
              <tab.icon className={`w-5 h-5 ${adminTab === tab.id ? 'text-[#1a120b]' : 'group-hover:text-[#d4af37]'}`} />
              <span className="text-[11px] uppercase tracking-[0.15em] font-bold font-sans">{tab.label}</span>
              {adminTab === tab.id && (
                <motion.div 
                  layoutId="activeAdminTab"
                  className="absolute left-0 top-0 h-full w-1 bg-[#1a120b]/20" 
                />
              )}
            </button>
          ))}
        </nav>

        <div className="p-8 border-t border-[#d4af37]/10 bg-[#0d0905]">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-3 bg-transparent text-[#d4af37]/60 px-6 py-4 rounded-sm text-[10px] uppercase tracking-widest font-bold hover:bg-[#d4af37] hover:text-[#1a120b] transition-all border border-[#d4af37]/20"
          >
            <LogOut className="w-4 h-4" />
            निर्गमनम् (Logout)
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-16 overflow-y-auto bg-[url('https://www.transparenttextures.com/patterns/paper-fibers.png')]">
        <div className="max-w-6xl mx-auto">
          <header className="mb-16">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-[1px] bg-[#d4af37]" />
              <span className="text-[#8b4513] text-[10px] uppercase tracking-[0.5em] font-bold opacity-60">Administrator Portal</span>
            </div>
            <h1 className="text-6xl font-serif font-bold text-[#1a120b] mb-6 tracking-tight">
              {adminTab === 'dashboard' && 'मुख्यपृष्ठम् [Dashboard]'}
              {adminTab === 'books' && 'ग्रन्थ सूची [Inventory]'}
              {adminTab === 'members' && 'सदस्य सूची [Members]'}
              {adminTab === 'approvals' && 'लम्बित अनुमोदनम् [Approvals]'}
              {adminTab === 'transactions' && 'विनिमय इतिहासः [Circulation]'}
              {adminTab === 'categories' && 'वर्ग प्रबन्धनम् [Categories]'}
              {adminTab === 'gifting' && 'ग्रन्थ उपहारः [Gifting]'}
              {adminTab === 'security' && 'लेखा सुरक्षा [Security]'}
            </h1>
          </header>

          <div className="bg-white p-14 shadow-[0_40px_100px_rgba(0,0,0,0.06)] border border-[#8b4513]/5 rounded-sm relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#d4af37]/40 to-transparent" />
            
            <AnimatePresence mode="wait">
              {adminTab === 'dashboard' && (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-12"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {[
                      { label: 'Total Books', value: books.length, icon: BookOpen, color: 'text-blue-600', bg: 'bg-blue-50' },
                      { label: 'Total Members', value: members.filter(m => m.status === 'approved').length, icon: Users, color: 'text-green-600', bg: 'bg-green-50' },
                      { label: 'Pending Approvals', value: members.filter(m => m.status === 'pending').length, icon: CheckCircle2, color: 'text-orange-600', bg: 'bg-orange-50' },
                      { label: 'Active Transactions', value: transactions.filter(t => !t.returnDate).length, icon: ArrowRightLeft, color: 'text-purple-600', bg: 'bg-purple-50' },
                    ].map((stat, i) => (
                      <motion.div
                        key={stat.label}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="bg-white p-8 rounded-sm border border-[#8b4513]/10 shadow-sm hover:shadow-md transition-all group"
                      >
                        <div className="flex items-center justify-between mb-6">
                          <div className={`p-4 ${stat.bg} rounded-sm group-hover:scale-110 transition-transform`}>
                            <stat.icon className={`w-6 h-6 ${stat.color}`} />
                          </div>
                          <span className="text-3xl font-serif font-bold text-[#1a120b]">{stat.value}</span>
                        </div>
                        <p className="text-[#8b4513]/60 text-[10px] uppercase tracking-[0.2em] font-sans font-bold">{stat.label}</p>
                      </motion.div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                    <div className="lg:col-span-2 space-y-8">
                      <div className="bg-[#f9f7f2] p-10 rounded-sm border border-[#8b4513]/10">
                        <h3 className="text-xl font-serif font-bold text-[#1a120b] mb-8 flex items-center gap-3">
                          <Clock className="w-5 h-5 text-[#d4af37]" />
                          Recent Activity [नवीनतम गतिविधयः]
                        </h3>
                        <div className="space-y-6">
                          {transactions.slice(0, 5).map((t, i) => {
                            const book = books.find(b => b.id === t.bookId);
                            const member = members.find(m => m.id === t.memberId);
                            return (
                              <div key={t.id} className="flex items-center gap-6 p-4 hover:bg-white rounded-sm transition-colors border-l-2 border-transparent hover:border-[#d4af37]">
                                <div className="w-10 h-10 bg-[#1a120b] text-[#d4af37] rounded-full flex items-center justify-center text-xs font-bold shrink-0">
                                  {i + 1}
                                </div>
                                <div className="flex-1">
                                  <p className="text-sm font-bold text-[#1a120b]">
                                    {book?.title} <span className="text-[#8b4513]/40 font-normal mx-2">issued to</span> {member?.name}
                                  </p>
                                  <p className="text-[10px] text-[#8b4513]/60 uppercase tracking-wider mt-1">{t.issueDate}</p>
                                </div>
                                <div className="text-[10px] font-bold text-[#d4af37] bg-[#d4af37]/5 px-3 py-1 rounded-full border border-[#d4af37]/10">
                                  {t.returnDate ? 'RETURNED' : 'ACTIVE'}
                                </div>
                              </div>
                            );
                          })}
                          {transactions.length === 0 && (
                            <p className="text-center py-10 text-[#8b4513]/40 italic">No recent transactions found.</p>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="bg-[#1a120b] p-10 rounded-sm shadow-xl border border-[#d4af37]/20">
                        <h3 className="text-xl font-serif font-bold text-[#d4af37] mb-8">Quick Actions</h3>
                        <div className="space-y-4">
                          <button 
                            onClick={() => { setBookForm({}); setModalType('addBook'); setIsModalOpen(true); }}
                            className="w-full flex items-center gap-4 p-4 bg-[#d4af37]/5 hover:bg-[#d4af37]/10 text-[#d4af37] rounded-sm border border-[#d4af37]/20 transition-all text-left group"
                          >
                            <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform" />
                            <span className="text-xs uppercase tracking-widest font-bold">Add New Book</span>
                          </button>
                          <button 
                            onClick={() => { setModalType('addMember'); setIsModalOpen(true); }}
                            className="w-full flex items-center gap-4 p-4 bg-[#d4af37]/5 hover:bg-[#d4af37]/10 text-[#d4af37] rounded-sm border border-[#d4af37]/20 transition-all text-left group"
                          >
                            <UserPlus className="w-5 h-5 group-hover:scale-110 transition-transform" />
                            <span className="text-xs uppercase tracking-widest font-bold">Register Member</span>
                          </button>
                          <button 
                            onClick={() => setAdminTab('approvals')}
                            className="w-full flex items-center gap-4 p-4 bg-[#d4af37]/5 hover:bg-[#d4af37]/10 text-[#d4af37] rounded-sm border border-[#d4af37]/20 transition-all text-left group"
                          >
                            <CheckCircle2 className="w-5 h-5 group-hover:scale-110 transition-transform" />
                            <span className="text-xs uppercase tracking-widest font-bold">Review Approvals</span>
                          </button>
                        </div>
                      </div>

                      <div className="bg-white p-10 rounded-sm border border-[#8b4513]/10 shadow-sm">
                        <h3 className="text-xl font-serif font-bold text-[#1a120b] mb-6">Library Health</h3>
                        <div className="space-y-6">
                          <div>
                            <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold text-[#8b4513]/60 mb-2">
                              <span>Inventory Utilization</span>
                              <span>{books.length > 0 ? Math.round((transactions.filter(t => !t.returnDate).length / books.length) * 100) : 0}%</span>
                            </div>
                            <div className="h-1.5 bg-[#f9f7f2] rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${books.length > 0 ? (transactions.filter(t => !t.returnDate).length / books.length) * 100 : 0}%` }}
                                className="h-full bg-[#d4af37]" 
                              />
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold text-[#8b4513]/60 mb-2">
                              <span>Member Growth</span>
                              <span>{members.length > 0 ? Math.round((members.filter(m => m.status === 'approved').length / members.length) * 100) : 0}%</span>
                            </div>
                            <div className="h-1.5 bg-[#f9f7f2] rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${members.length > 0 ? (members.filter(m => m.status === 'approved').length / members.length) * 100 : 0}%` }}
                                className="h-full bg-[#556b2f]" 
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {adminTab === 'books' && (
                <motion.div
                  key="books"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-8">
                    <h2 className="text-3xl font-bold text-[#2c1e12] border-l-4 border-[#d4af37] pl-6">Book Collection</h2>
                    <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
                      <div className="relative group flex-1 md:w-96">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b4513]/30 group-focus-within:text-[#d4af37] transition-colors" />
                        <input 
                          type="text" 
                          placeholder="Search by Book ID (e.g. SMR/CAT/2026/1)..."
                          className="w-full bg-[#f9f7f2] border-2 border-[#8b4513]/10 pl-12 pr-4 py-4 rounded-sm focus:outline-none focus:border-[#d4af37] transition-all text-sm font-sans"
                          value={bookSearchQuery}
                          onChange={(e) => setBookSearchQuery(e.target.value)}
                        />
                      </div>
                      <div className="flex gap-4">
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={exportInventoryPDF}
                          className="bg-[#2c1e12] text-[#d4af37] px-8 py-4 rounded-sm flex items-center gap-3 text-xs uppercase tracking-widest font-bold hover:bg-[#3d2b1a] transition-all shadow-lg whitespace-nowrap border border-[#d4af37]/20"
                        >
                          <Download className="w-4 h-4" />
                          PDF निर्यात [Export]
                        </motion.button>
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => { setBookForm({}); setModalType('addBook'); setIsModalOpen(true); }}
                          className="bg-[#556b2f] text-white px-10 py-4 rounded-sm flex items-center gap-3 text-xs uppercase tracking-widest font-bold hover:bg-[#455a25] transition-all shadow-lg whitespace-nowrap"
                        >
                          <Plus className="w-4 h-4" />
                          नवीन ग्रन्थः [Add]
                        </motion.button>
                      </div>
                    </div>
                  </div>
                  <div className="overflow-x-auto rounded-sm border border-[#8b4513]/10">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b-2 border-[#2c1e12]/10 bg-[#f9f7f2]">
                          <th className="p-6 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">पञ्जीकरण ID [Reg ID]</th>
                          <th className="p-6 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">शीर्षकम् [Title]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">लेखकः [Author]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">वर्गः [Category]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">स्थितिः [Status]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold text-right">क्रिया [Actions]</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#8b4513]/10">
                      {books
                        .filter(book => book.id.toLowerCase().includes(bookSearchQuery.toLowerCase()))
                        .map((book) => {
                          const status = getBookStatus(book.id);
                          return (
                            <motion.tr 
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              key={book.id} 
                              className="hover:bg-[#f9f7f2]/50 transition-colors"
                            >
                              <td className="p-5 font-mono text-[10px] font-bold text-[#8b4513]">{book.id}</td>
                              <td className="p-5 font-bold text-[#2c1e12]">{book.title}</td>
                              <td className="p-5 text-[#5d4037] italic">{book.author}</td>
                              <td className="p-5 text-sm text-[#5d4037]">{book.category}</td>
                              <td className="p-5">
                                <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${status.bg} ${status.color}`}>
                                  {status.label}
                                </span>
                              </td>
                              <td className="p-5 text-right">
                                <div className="flex justify-end gap-2">
                                  {book.billData && (
                                    <button 
                                      onClick={() => { setSelectedBill(book.billData); setModalType('viewBill'); setIsModalOpen(true); }}
                                      className="p-2 text-[#556b2f] hover:bg-[#556b2f]/10 rounded-full transition-all"
                                      title="View Bill"
                                    >
                                      <History className="w-4 h-4" />
                                    </button>
                                  )}
                                  <button 
                                    onClick={() => { setBookForm(book); setModalType('editBook'); setIsModalOpen(true); }}
                                    className="p-2 text-[#2c1e12] hover:bg-[#2c1e12]/10 rounded-full transition-all"
                                    title="Edit Book"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={() => { setItemToDelete(book.id); setModalType('confirmDeleteBook'); setIsModalOpen(true); }}
                                    className="p-2 text-[#8b4513]/40 hover:text-red-700 hover:bg-red-50 rounded-full transition-all"
                                    title="Delete Book (ग्रन्थं निष्कासयतु)"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </motion.tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {adminTab === 'categories' && (
              <motion.div
                key="categories"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
                  <h2 className="text-2xl font-bold text-[#2c1e12]">वर्ग प्रबन्धनम् [Category Management]</h2>
                </div>
                <form onSubmit={handleAddCategory} className="flex gap-4 mb-10 max-w-md">
                  <input 
                    type="text" 
                    required 
                    placeholder="New Category Name..."
                    className="flex-1 bg-white border-2 border-[#8b4513]/10 px-4 py-2 focus:outline-none focus:border-[#d4af37]"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                  />
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    type="submit" 
                    className="bg-[#2c1e12] text-[#d4af37] px-6 py-2 text-xs uppercase font-bold tracking-widest"
                  >
                    Add [योजयतु]
                  </motion.button>
                </form>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {categories.map((cat) => (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      key={cat} 
                      className="bg-[#f9f7f2] border border-[#8b4513]/20 p-4 flex justify-between items-center group"
                    >
                      <span className="text-sm font-bold text-[#2c1e12]">{cat}</span>
                      <button 
                        onClick={() => handleDeleteCategory(cat)}
                        className="text-[#8b4513]/30 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {adminTab === 'members' && (
              <motion.div
                key="members"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
                  <h2 className="text-2xl font-bold text-[#2c1e12]">सदस्य सूची [Library Members]</h2>
                  <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
                    <div className="relative group flex-1 md:w-80">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b4513]/30 group-focus-within:text-[#d4af37] transition-colors" />
                      <input 
                        type="text" 
                        placeholder="Search by Member ID (e.g. SMR/MEM/2026/1)..."
                        className="w-full bg-[#f9f7f2] border-2 border-[#8b4513]/10 pl-12 pr-4 py-3 rounded-sm focus:outline-none focus:border-[#d4af37] transition-all text-sm"
                        value={memberSearchQuery}
                        onChange={(e) => setMemberSearchQuery(e.target.value)}
                      />
                    </div>
                    <div className="flex gap-4">
                      <motion.button 
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={exportMembersPDF}
                        className="bg-[#2c1e12] text-[#d4af37] px-6 py-3 rounded-sm flex items-center gap-3 text-xs uppercase tracking-widest font-bold hover:bg-[#3d2b1a] transition-all shadow-md whitespace-nowrap"
                      >
                        <Download className="w-4 h-4" />
                        PDF निर्यात [Export PDF]
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => { setModalType('addMember'); setIsModalOpen(true); }}
                        className="bg-[#556b2f] text-white px-8 py-3 rounded-sm flex items-center gap-3 text-xs uppercase tracking-widest font-bold hover:bg-[#455a25] transition-all shadow-md whitespace-nowrap"
                      >
                        <UserPlus className="w-4 h-4" />
                        नवीन सदस्यः [New Member]
                      </motion.button>
                    </div>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b-2 border-[#2c1e12]/10 bg-[#f9f7f2]">
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">सदस्य ID [Member ID]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">नाम [Name]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">सम्पर्कः [Contact]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold">विवरणम् [Details]</th>
                        <th className="p-5 text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold text-right">क्रिया [Actions]</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#8b4513]/10">
                      {members
                        .filter(m => m.status === 'approved')
                        .filter(member => member.id.toLowerCase().includes(memberSearchQuery.toLowerCase()))
                        .map((member) => (
                          <motion.tr 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            key={member.id} 
                            className="hover:bg-[#f9f7f2]/50 transition-colors"
                          >
                            <td className="p-5">
                              <div className="flex items-center gap-4">
                                {member.photo ? (
                                  <img src={member.photo} alt={member.name} className="w-10 h-10 object-cover rounded-full border border-[#d4af37]" referrerPolicy="no-referrer" />
                                ) : (
                                  <div className="w-10 h-10 bg-[#2c1e12] text-[#d4af37] rounded-full flex items-center justify-center text-xs font-bold">
                                    {member.name[0]}
                                  </div>
                                )}
                                <span className="font-mono text-[10px] font-bold text-[#8b4513]">{member.id}</span>
                              </div>
                            </td>
                            <td className="p-5">
                              <div className="font-bold text-[#2c1e12]">{member.name}</div>
                              <div className="text-[10px] uppercase tracking-widest text-[#8b4513] opacity-60">{member.fatherName}</div>
                            </td>
                            <td className="p-5">
                              <div className="text-sm text-[#5d4037]">{member.email}</div>
                              <div className="text-xs text-[#8b4513]/60">{member.mobile}</div>
                            </td>
                            <td className="p-5">
                              <div className="text-xs text-[#5d4037]">DOB: {member.dob}</div>
                              <div className="text-xs text-[#5d4037]">Joined: {member.joinedDate}</div>
                            </td>
                            <td className="p-5 text-right">
                              <div className="flex justify-end gap-2">
                                <button 
                                  onClick={() => { setMemberForm(member); setModalType('editMember'); setIsModalOpen(true); }}
                                  className="p-2 text-[#2c1e12] hover:bg-[#2c1e12]/10 rounded-full transition-all"
                                  title="Edit Member"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                                <button 
                                  onClick={() => generateIDCard(member)}
                                  className="p-2 text-[#556b2f] hover:bg-[#556b2f]/10 rounded-full transition-all"
                                  title="Download ID Card"
                                >
                                  <Download className="w-4 h-4" />
                                </button>
                                <button 
                                  onClick={() => { setItemToDelete(member.id); setModalType('confirmDeleteMember'); setIsModalOpen(true); }}
                                  className="p-2 text-[#8b4513]/40 hover:text-red-700 hover:bg-red-50 rounded-full transition-all"
                                  title="Delete Member (सदस्यं निष्कासयतु)"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </motion.tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {adminTab === 'approvals' && (
              <motion.div
                key="approvals"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-10"
              >
                <div className="bg-white p-10 rounded-sm shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-[#d4af37]/10">
                  <div className="flex items-center gap-6 mb-12 border-b border-[#d4af37]/10 pb-8">
                    <div className="p-4 bg-[#d4af37]/5 rounded-full">
                      <CheckCircle2 className="w-8 h-8 text-[#d4af37]" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-serif font-bold text-[#1a120b]">Membership Approvals</h2>
                      <p className="text-[#8b4513]/60 text-[10px] uppercase tracking-[0.2em] font-sans font-bold mt-1">Review and welcome new seekers of wisdom</p>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#fdfaf5] border-b border-[#d4af37]/20">
                          <th className="p-6 text-[11px] uppercase tracking-[0.2em] text-[#8b4513] font-sans font-bold">Candidate Details</th>
                          <th className="p-6 text-[11px] uppercase tracking-[0.2em] text-[#8b4513] font-sans font-bold">Contact Information</th>
                          <th className="p-6 text-[11px] uppercase tracking-[0.2em] text-[#8b4513] font-sans font-bold">Application Metadata</th>
                          <th className="p-6 text-[11px] uppercase tracking-[0.2em] text-[#8b4513] font-sans font-bold text-right">Decision</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#d4af37]/5">
                        {members
                          .filter(m => m.status === 'pending')
                          .map((member) => (
                            <motion.tr 
                              layout
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              key={member.id} 
                              className="hover:bg-[#fdfaf5] transition-colors group"
                            >
                              <td className="p-6">
                                <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 rounded-full bg-[#1a120b] flex items-center justify-center overflow-hidden border border-[#d4af37]/20">
                                    {member.photo ? (
                                      <img src={member.photo} alt={member.name} className="w-full h-full object-cover" />
                                    ) : (
                                      <span className="text-[#d4af37] font-bold">{member.name.charAt(0)}</span>
                                    )}
                                  </div>
                                  <div>
                                    <div className="font-bold text-[#1a120b] text-lg">{member.name}</div>
                                    <div className="text-[10px] uppercase tracking-widest text-[#8b4513] opacity-60">S/O: {member.fatherName}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="p-6">
                                <div className="text-sm font-sans text-[#1a120b] font-medium">{member.email}</div>
                                <div className="text-[11px] text-[#8b4513]/60 font-mono mt-1">{member.mobile}</div>
                              </td>
                              <td className="p-6">
                                <div className="text-[11px] text-[#1a120b] font-mono">Aadhaar: {member.aadhaar}</div>
                                <div className="text-[11px] text-[#8b4513]/60 mt-1 font-sans">Applied: {member.joinedDate}</div>
                              </td>
                              <td className="p-6 text-right">
                                <div className="flex justify-end gap-3">
                                  <button 
                                    disabled={isProcessing}
                                    onClick={() => handleApproveMember(member.id)}
                                    className="bg-[#1a120b] text-[#d4af37] px-6 py-2.5 text-[10px] uppercase font-bold tracking-widest rounded-sm border border-[#d4af37]/30 hover:bg-[#d4af37] hover:text-[#1a120b] transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
                                  >
                                    {isProcessing && processingType === 'update' ? 'Processing...' : 'Approve [अनुमोदयतु]'}
                                  </button>
                                  <button 
                                    disabled={isProcessing}
                                    onClick={() => { setItemToDelete(member.id); setModalType('confirmDeleteMember'); setIsModalOpen(true); }}
                                    className="bg-transparent text-red-800/60 border border-red-800/20 px-6 py-2.5 text-[10px] uppercase font-bold tracking-widest rounded-sm hover:bg-red-50 hover:text-red-800 transition-all disabled:opacity-50"
                                  >
                                    Reject [अस्वीकरोतु]
                                  </button>
                                </div>
                              </td>
                            </motion.tr>
                          ))}
                        {members.filter(m => m.status === 'pending').length === 0 && (
                          <tr>
                            <td colSpan={4} className="p-20 text-center">
                              <div className="flex flex-col items-center gap-4 opacity-30">
                                <CheckCircle2 className="w-12 h-12 text-[#d4af37]" />
                                <p className="text-[#8b4513] font-serif italic">All applications have been processed.</p>
                              </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {adminTab === 'transactions' && (
              <motion.div
                key="transactions"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
                  <h2 className="text-2xl font-bold text-[#2c1e12]">विनिमय लेखा [Circulation Records]</h2>
                  <div className="flex gap-4">
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={exportCirculationPDF}
                      className="bg-[#2c1e12] text-[#d4af37] px-6 py-3 rounded-sm flex items-center gap-3 text-xs uppercase tracking-widest font-bold hover:bg-[#3d2b1a] transition-all shadow-md"
                    >
                      <Download className="w-4 h-4" />
                      PDF निर्यात [Export PDF]
                    </motion.button>
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => { setModalType('issueBook'); setIsModalOpen(true); }}
                      className="bg-[#556b2f] text-white px-8 py-3 rounded-sm flex items-center gap-3 text-xs uppercase tracking-widest font-bold hover:bg-[#455a25] transition-all shadow-md"
                    >
                      <ArrowRightLeft className="w-4 h-4" />
                      ग्रन्थ निर्गमनम् [Issue Book]
                    </motion.button>
                  </div>
                </div>
                <div className="space-y-6">
                  {transactions.map((t) => (
                    <motion.div 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      key={t.id} 
                      className={`p-8 rounded-sm border-2 flex flex-col lg:flex-row justify-between items-center gap-8 ${t.returnDate ? 'bg-zinc-50 border-[#8b4513]/5 opacity-70' : 'bg-white border-[#8b4513]/20 shadow-lg'}`}
                    >
                      <div className="flex items-center gap-6 w-full lg:w-auto">
                        <div className={`w-14 h-14 rounded-full flex items-center justify-center ${t.returnDate ? 'bg-zinc-200 text-zinc-500' : 'bg-[#d4af37]/20 text-[#8b4513]'}`}>
                          {t.returnDate ? <CheckCircle2 className="w-7 h-7" /> : <Clock className="w-7 h-7" />}
                        </div>
                        <div>
                          <div className="text-xl font-bold text-[#2c1e12]">{t.book?.title}</div>
                          <div className="text-[10px] uppercase tracking-[0.2em] text-[#8b4513] font-sans font-bold mt-1">Issued to: {t.member?.name}</div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-10 text-center flex-1">
                        <div>
                          <div className="text-[10px] uppercase tracking-widest text-[#8b4513]/40 font-sans font-bold mb-2">निर्गमनम् (Issued)</div>
                          <div className="text-sm font-bold text-[#2c1e12]">{t.issueDate}</div>
                        </div>
                        <div>
                          <div className="text-[10px] uppercase tracking-widest text-[#8b4513]/40 font-sans font-bold mb-2">अन्तिमतिथिः (Due)</div>
                          <div className="text-sm font-bold text-red-700">{t.dueDate}</div>
                        </div>
                        {t.returnDate && (
                          <div className="col-span-2 md:col-span-1">
                            <div className="text-[10px] uppercase tracking-widest text-[#8b4513]/40 font-sans font-bold mb-2">प्रतिदानम् (Returned)</div>
                            <div className="text-sm font-bold text-[#556b2f]">{t.returnDate}</div>
                          </div>
                        )}
                      </div>
                      
                      {!t.returnDate && (
                        <motion.button 
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleReceiveBook(t.id)}
                          className="w-full lg:w-auto bg-[#2c1e12] text-[#d4af37] px-8 py-3 rounded-sm text-[10px] uppercase tracking-widest font-bold hover:bg-[#3d2b1a] transition-all shadow-md"
                        >
                          ग्रन्थ प्राप्तिः (Receive)
                        </motion.button>
                      )}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {adminTab === 'gifting' && (
              <motion.div
                key="gifting"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
                  <h2 className="text-2xl font-bold text-[#2c1e12]">ग्रन्थ उपहारः [Book Gifting]</h2>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                  <div className="lg:col-span-1">
                    <div className="bg-[#f9f7f2] p-8 border-2 border-[#8b4513]/10 rounded-sm">
                      <h3 className="text-lg font-bold text-[#2c1e12] mb-6 border-b border-[#8b4513]/10 pb-4 flex items-center gap-3">
                        <Gift className="w-5 h-5 text-[#d4af37]" />
                        नवीन उपहारः [New Gift]
                      </h3>
                      <form onSubmit={handleGiftBook} className="space-y-6">
                        <div>
                          <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2">ग्रन्थ ID [Book ID]</label>
                          <input 
                            type="text" 
                            required 
                            placeholder="e.g. SMR/CAT/2026/1"
                            className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] text-sm font-mono"
                            value={giftForm.bookId}
                            onChange={(e) => setGiftForm({ ...giftForm, bookId: e.target.value })}
                          />
                          {giftForm.bookId && (
                            <div className="mt-2 p-2 bg-[#d4af37]/5 border border-[#d4af37]/20 rounded-sm">
                              <p className="text-[10px] uppercase tracking-widest text-[#8b4513]/60 font-bold mb-1">Book Name:</p>
                              <p className="text-sm font-bold text-[#2c1e12]">
                                {books.find(b => b.id === giftForm.bookId)?.title || <span className="text-red-500 italic">Not Found</span>}
                              </p>
                            </div>
                          )}
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2">सदस्य ID [Member ID]</label>
                          <input 
                            type="text" 
                            required 
                            placeholder="e.g. SMR/MEM/2026/1"
                            className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] text-sm font-mono"
                            value={giftForm.memberId}
                            onChange={(e) => setGiftForm({ ...giftForm, memberId: e.target.value })}
                          />
                          {giftForm.memberId && (
                            <div className="mt-2 p-2 bg-[#d4af37]/5 border border-[#d4af37]/20 rounded-sm">
                              <p className="text-[10px] uppercase tracking-widest text-[#8b4513]/60 font-bold mb-1">Member Name:</p>
                              <p className="text-sm font-bold text-[#2c1e12]">
                                {members.find(m => m.id === giftForm.memberId)?.name || <span className="text-red-500 italic">Not Found</span>}
                              </p>
                            </div>
                          )}
                        </div>
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          type="submit" 
                          className="w-full bg-[#556b2f] text-white py-4 rounded-sm text-xs uppercase font-bold tracking-widest hover:bg-[#455a25] transition-all shadow-md"
                        >
                          उपहारं ददातु [Give Gift]
                        </motion.button>
                      </form>
                    </div>
                  </div>

                  <div className="lg:col-span-2">
                    <h3 className="text-lg font-bold text-[#2c1e12] mb-6 flex items-center gap-3">
                      <History className="w-5 h-5 text-[#8b4513]/40" />
                      उपहार इतिहासः [Gift History]
                    </h3>
                    <div className="space-y-4">
                      {gifts.length === 0 ? (
                        <div className="text-center py-20 bg-[#f9f7f2] border border-dashed border-[#8b4513]/20 text-[#8b4513]/40 italic">
                          No gifts recorded yet.
                        </div>
                      ) : (
                        gifts.map((gift) => (
                          <motion.div 
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            key={gift.id} 
                            className="bg-white border-2 border-[#8b4513]/10 p-6 flex justify-between items-center group hover:border-[#d4af37] transition-all"
                          >
                            <div className="flex items-center gap-6">
                              <div className="w-12 h-12 bg-[#556b2f]/10 text-[#556b2f] rounded-full flex items-center justify-center">
                                <Gift className="w-6 h-6" />
                              </div>
                              <div>
                                <div className="font-bold text-[#2c1e12]">{gift.book?.title || 'Unknown Book'}</div>
                                <div className="text-[10px] uppercase tracking-widest text-[#8b4513] font-bold mt-1">
                                  Gifted to: {gift.member?.name || 'Unknown Member'}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-[10px] uppercase tracking-widest text-[#8b4513]/40 font-bold mb-1">Date</div>
                              <div className="text-sm font-bold text-[#2c1e12]">{gift.giftDate}</div>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {adminTab === 'security' && (
              <motion.div
                key="security"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
                  <h2 className="text-2xl font-bold text-[#2c1e12]">लेखा सुरक्षा [Account Security]</h2>
                </div>
                
                <div className="max-w-2xl bg-white p-12 border-2 border-[#8b4513]/10 rounded-sm shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-2 bg-[#d4af37]" />
                  <div className="flex items-start gap-8 mb-12">
                    <div className="w-16 h-16 bg-[#2c1e12] text-[#d4af37] rounded-sm flex items-center justify-center shadow-lg">
                      <CheckCircle2 className="w-8 h-8" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-[#2c1e12] mb-2">ग्रन्थाध्यक्ष विवरणम् [Librarian Credentials]</h3>
                      <p className="text-[#8b4513] text-sm italic">Update your administrative access credentials here. Ensure you use a strong password.</p>
                    </div>
                  </div>

                  <form onSubmit={handleUpdateAccount} className="space-y-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-[0.2em] text-[#8b4513] font-sans font-bold mb-3 group-focus-within:text-[#d4af37] transition-colors">नवीन प्रयोक्तृनाम [New Username]</label>
                        <input 
                          type="text" 
                          placeholder={`Current: ${user?.username || 'librarian'}`}
                          className="w-full bg-[#f9f7f2] border-2 border-[#8b4513]/10 px-6 py-4 focus:outline-none focus:border-[#d4af37] transition-all font-serif"
                          value={securityForm.username}
                          onChange={(e) => setSecurityForm({ ...securityForm, username: e.target.value })}
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-[0.2em] text-[#8b4513] font-sans font-bold mb-3 group-focus-within:text-[#d4af37] transition-colors">नवीन कूटशब्दः [New Password]</label>
                        <input 
                          type="password" 
                          placeholder="••••••••"
                          className="w-full bg-[#f9f7f2] border-2 border-[#8b4513]/10 px-6 py-4 focus:outline-none focus:border-[#d4af37] transition-all font-serif"
                          value={securityForm.password}
                          onChange={(e) => setSecurityForm({ ...securityForm, password: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="pt-6 border-t border-[#8b4513]/10">
                      <motion.button 
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        type="submit" 
                        className="bg-[#2c1e12] text-[#d4af37] px-12 py-4 text-xs uppercase font-bold tracking-[0.3em] hover:bg-[#3d2b1a] transition-all shadow-lg"
                      >
                        विवरणं रक्षतु [Save Credentials]
                      </motion.button>
                    </div>
                  </form>
                </div>
              </motion.div>
            )}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f2ed] selection:bg-[#d4af37]/30 selection:text-[#2c1e12]">
      {view !== 'admin' && <Navbar user={user} setView={setView} />}
      <main>
        <AnimatePresence mode="wait">
          {view === 'landing' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
            >
              <LandingPage setView={setView} />
            </motion.div>
          )}
          {view === 'login' && (
            <motion.div
              key="login"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              <LoginPage 
                loginForm={loginForm} 
                setLoginForm={setLoginForm} 
                handleLogin={handleLogin} 
                loginError={loginError} 
                isProcessing={isProcessing} 
                setView={setView}
              />
            </motion.div>
          )}
          {view === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <AdminPanel 
                adminTab={adminTab}
                setAdminTab={setAdminTab}
                user={user}
                books={books}
                members={members}
                transactions={transactions}
                categories={categories}
                gifts={gifts}
                demands={demands}
                isProcessing={isProcessing}
                processingType={processingType || ''}
                handleLogout={handleLogout}
                handleApproveMember={handleApproveMember}
                handleApproveDemand={handleApproveDemand}
                handleDeleteBook={handleDeleteBook}
                handleDeleteMember={handleDeleteMember}
                handleDeleteCategory={handleDeleteCategory}
                handleReceiveBook={handleReceiveBook}
                setModalType={setModalType}
                setIsModalOpen={setIsModalOpen}
                setBookForm={setBookForm}
                setMemberForm={setMemberForm}
                setItemToDelete={setItemToDelete}
                setSecurityForm={setSecurityForm}
                securityForm={securityForm}
                handleUpdateAccount={handleUpdateAccount}
                giftForm={giftForm}
                setGiftForm={setGiftForm}
                handleGiftBook={handleGiftBook}
                exportInventoryPDF={exportInventoryPDF}
                exportMembersPDF={exportMembersPDF}
                exportCirculationPDF={exportCirculationPDF}
                generateIDCard={generateIDCard}
                bookSearchQuery={bookSearchQuery}
                setBookSearchQuery={setBookSearchQuery}
                memberSearchQuery={memberSearchQuery}
                setMemberSearchQuery={setMemberSearchQuery}
                handleAddCategory={handleAddCategory}
                newCategory={newCategory}
                setNewCategory={setNewCategory}
                setSelectedBill={setSelectedBill}
              />
            </motion.div>
          )}
          {view === 'signup' && (
            <motion.div
              key="signup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <SignupPage 
                signupForm={signupForm}
                setSignupForm={setSignupForm}
                handleSignup={handleSignup}
                handlePhotoChange={handlePhotoChange}
                setView={setView}
              />
            </motion.div>
          )}
          {view === 'member' && (
            <motion.div
              key="member"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <MemberPanel 
                memberTab={memberTab}
                setMemberTab={setMemberTab}
                user={user}
                books={books}
                handleLogout={handleLogout}
                handleDemandBook={handleDemandBook}
                memberDemands={memberDemands}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-[#2c1e12]/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="relative bg-[#f5f2ed] w-full max-w-lg rounded-sm p-10 shadow-2xl border-t-8 border-[#d4af37] font-serif"
            >
              <button 
                onClick={() => setIsModalOpen(false)}
                className="absolute top-6 right-6 p-2 hover:bg-[#8b4513]/10 rounded-full transition-colors text-[#8b4513]"
              >
                <X className="w-5 h-5" />
              </button>

              {(modalType === 'addBook' || modalType === 'editBook') && (
                <form onSubmit={handleAddBook} className="space-y-6 max-h-[80vh] overflow-y-auto pr-4 scrollbar-hide relative">
                  {/* Decorative Graphic */}
                  <div className="absolute -top-10 -right-10 opacity-5 pointer-events-none">
                    <Scroll className="w-40 h-40 text-[#8b4513]" />
                  </div>

                  <h3 className="text-3xl font-bold text-[#2c1e12] mb-8 border-b-2 border-[#d4af37]/30 pb-4 flex items-center gap-3">
                    <BookOpen className="w-8 h-8 text-[#d4af37]" />
                    <span>
                      {modalType === 'editBook' ? 'ग्रन्थ संशोधनम् [Edit Volume]' : 'नवीन ग्रन्थ पञ्जीकरणम् [Add New Volume]'}
                    </span>
                  </h3>

                  <div className="grid grid-cols-1 gap-6">
                    <div className="group">
                      <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">शीर्षकम् [Book Title]</label>
                      <input 
                        required 
                        className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors bg-[url('https://www.transparenttextures.com/patterns/paper-fibers.png')]" 
                        value={bookForm.title || ''}
                        onChange={e => setBookForm({...bookForm, title: e.target.value})} 
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">लेखकः [Author Name]</label>
                        <input 
                          required 
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={bookForm.author || ''}
                          onChange={e => setBookForm({...bookForm, author: e.target.value})} 
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">प्रकाशकः [Publisher's Details]</label>
                        <input 
                          required 
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={bookForm.publisher || ''}
                          onChange={e => setBookForm({...bookForm, publisher: e.target.value})} 
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">वर्गः [Category]</label>
                        <div className="relative">
                          <select 
                            required 
                            className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] appearance-none transition-colors"
                            value={bookForm.category || ''}
                            onChange={e => setBookForm({...bookForm, category: e.target.value})}
                          >
                            <option value="">Select Category...</option>
                            {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                          </select>
                          <Bookmark className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b4513]/30 pointer-events-none" />
                        </div>
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">पञ्जीकरण वर्षम् [Registration Year]</label>
                        <input 
                          type="number" 
                          required 
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={bookForm.regYear || new Date().getFullYear()}
                          onChange={e => setBookForm({...bookForm, regYear: parseInt(e.target.value)})} 
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">प्रकाशन वर्षम् [Publication Year]</label>
                        <input 
                          type="number" 
                          required 
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={bookForm.year || ''}
                          onChange={e => setBookForm({...bookForm, year: parseInt(e.target.value)})} 
                        />
                      </div>
                      <div className="flex items-center gap-4 pt-6">
                        <div className="relative flex items-center">
                          <input 
                            type="checkbox" 
                            id="isGift" 
                            className="w-6 h-6 accent-[#2c1e12] cursor-pointer" 
                            checked={bookForm.isGift || false}
                            onChange={e => setBookForm({...bookForm, isGift: e.target.checked})} 
                          />
                        </div>
                        <label htmlFor="isGift" className="text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold cursor-pointer">उपहारः [Gifted Volume]</label>
                      </div>
                    </div>

                    <div className="group">
                      <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">क्रय-विपत्रम् [Purchase Bill - PDF max 200KB]</label>
                      <div className="border-2 border-dashed border-[#8b4513]/20 p-4 bg-[#f9f7f2] hover:border-[#d4af37] transition-colors relative">
                        <input 
                          type="file" 
                          accept="application/pdf"
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                          onChange={handleFileUpload}
                        />
                        <div className="flex items-center justify-center gap-3 text-[#8b4513]/60">
                          <History className="w-5 h-5" />
                          <span className="text-xs font-bold uppercase tracking-widest">
                            {bookForm.billData ? 'विपत्रं संलग्न् [Bill Attached]' : 'विपत्रं चिन्वान्तु [Choose PDF]'}
                          </span>
                        </div>
                      </div>
                      {bookForm.billData && <p className="text-[10px] text-[#556b2f] mt-2 font-bold flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> विपत्रं सफलतया संलग्न् [Bill successfully attached]</p>}
                    </div>

                    <div className="group">
                      <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">विवरणम् [Description]</label>
                      <textarea 
                        required 
                        className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] h-28 resize-none transition-colors" 
                        value={bookForm.description || ''}
                        onChange={e => setBookForm({...bookForm, description: e.target.value})} 
                      />
                    </div>
                  </div>

                  <div className="pt-4">
                    <button 
                      type="submit" 
                      className="w-full bg-[#2c1e12] text-[#d4af37] py-5 text-sm uppercase tracking-[0.4em] font-bold shadow-[0_10px_20px_rgba(0,0,0,0.2)] hover:bg-[#3d2b1a] active:scale-[0.98] transition-all border border-[#d4af37]/30"
                    >
                      {modalType === 'editBook' ? 'संशोधनं रक्षतु [Save Changes]' : 'ग्रन्थं पञ्जीकरोतु [Register Volume]'}
                    </button>
                  </div>
                </form>
              )}

              {modalType === 'confirmDeleteBook' && (
                <div className="text-center py-10">
                  <div className="w-24 h-24 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner border-4 border-white">
                    <Trash2 className="w-12 h-12" />
                  </div>
                  <h3 className="text-3xl font-bold text-[#2c1e12] mb-4">ग्रन्थं निष्कासयितुं निश्चितम्?</h3>
                  <p className="text-[#8b4513] text-sm uppercase tracking-widest font-bold mb-10">
                    [Are you sure you want to delete this volume?]
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 border-2 border-[#8b4513]/20 text-[#8b4513] py-5 text-xs uppercase tracking-widest font-bold hover:bg-[#8b4513]/5 transition-all active:scale-95"
                    >
                      निरस्तं करोतु [Cancel]
                    </button>
                    <button 
                      onClick={handleDeleteBook}
                      className="flex-1 bg-red-700 text-white py-5 text-xs uppercase tracking-widest font-bold hover:bg-red-800 transition-all shadow-lg active:scale-95"
                    >
                      निश्चितं निष्कासयतु [Confirm Delete]
                    </button>
                  </div>
                </div>
              )}

              {modalType === 'confirmDeleteMember' && (
                <div className="text-center py-10">
                  <div className="w-24 h-24 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner border-4 border-white">
                    <Trash2 className="w-12 h-12" />
                  </div>
                  <h3 className="text-3xl font-bold text-[#2c1e12] mb-4">सदस्यं निष्कासयितुं निश्चितम्?</h3>
                  <p className="text-[#8b4513] text-sm uppercase tracking-widest font-bold mb-10">
                    [Are you sure you want to delete this member?]
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 border-2 border-[#8b4513]/20 text-[#8b4513] py-5 text-xs uppercase tracking-widest font-bold hover:bg-[#8b4513]/5 transition-all active:scale-95"
                    >
                      निरस्तं करोतु [Cancel]
                    </button>
                    <button 
                      onClick={handleDeleteMember}
                      className="flex-1 bg-red-700 text-white py-5 text-xs uppercase tracking-widest font-bold hover:bg-red-800 transition-all shadow-lg active:scale-95"
                    >
                      निश्चितं निष्कासयतु [Confirm Delete]
                    </button>
                  </div>
                </div>
              )}

              {(modalType === 'addMember' || modalType === 'editMember') && (
                <form onSubmit={modalType === 'addMember' ? handleAddMember : handleEditMember} className="space-y-8 relative">
                  <div className="absolute -top-10 -right-10 opacity-5 pointer-events-none">
                    <UserPlus className="w-40 h-40 text-[#8b4513]" />
                  </div>
                  <h3 className="text-3xl font-bold text-[#2c1e12] mb-8 border-b-2 border-[#d4af37]/30 pb-4 flex items-center gap-3">
                    <Users className="w-8 h-8 text-[#d4af37]" />
                    <span>{modalType === 'addMember' ? 'नवीन सदस्य पञ्जीकरणम् [New Member Registration]' : 'सदस्य संशोधनम् [Edit Member]'}</span>
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">पूर्णनाम [Full Name]</label>
                        <input 
                          required 
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={memberForm.name || ''}
                          onChange={e => setMemberForm({...memberForm, name: e.target.value})} 
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">पितुः नाम [Father's Name]</label>
                        <input 
                          required 
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={memberForm.fatherName || ''}
                          onChange={e => setMemberForm({...memberForm, fatherName: e.target.value})} 
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">जन्म तिथि [Date of Birth]</label>
                        <input 
                          required 
                          type="date"
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={memberForm.dob || ''}
                          onChange={e => setMemberForm({...memberForm, dob: e.target.value})} 
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">आधार सङ्ख्या [Aadhaar: XXXX - XXXX - XXXX]</label>
                        <input 
                          required 
                          placeholder="XXXX - XXXX - XXXX"
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={memberForm.aadhaar || ''}
                          onChange={e => {
                            let val = e.target.value.replace(/\D/g, '').substring(0, 12);
                            let formatted = val.match(/.{1,4}/g)?.join(' - ') || val;
                            setMemberForm({...memberForm, aadhaar: formatted});
                          }} 
                        />
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">भ्रमणभाष सङ्ख्या [Mobile: +91 - XXXXXXXXXX]</label>
                        <input 
                          required 
                          placeholder="+91 - XXXXXXXXXX"
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={memberForm.mobile || ''}
                          onChange={e => {
                            let val = e.target.value.replace(/\D/g, '');
                            if (val.startsWith('91')) val = val.substring(2);
                            val = val.substring(0, 10);
                            let formatted = val ? `+91 - ${val}` : '';
                            setMemberForm({...memberForm, mobile: formatted});
                          }} 
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">ई-पत्रम् [Email ID]</label>
                        <input 
                          required 
                          type="email"
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={memberForm.email || ''}
                          onChange={e => setMemberForm({...memberForm, email: e.target.value})} 
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">प्रवेश तिथि [Joining Date]</label>
                        <input 
                          required 
                          type="date"
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-colors" 
                          value={memberForm.joinedDate || ''}
                          onChange={e => setMemberForm({...memberForm, joinedDate: e.target.value})} 
                        />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">सदस्य चित्रम् [Member Photo - Max 50KB]</label>
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 border-2 border-[#8b4513]/10 bg-[#f9f7f2] flex items-center justify-center overflow-hidden">
                            {memberForm.photo ? (
                              <img src={memberForm.photo} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <Users className="w-8 h-8 text-[#8b4513]/20" />
                            )}
                          </div>
                          <div className="flex-1 relative">
                            <input 
                              type="file" 
                              accept="image/*"
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                              onChange={handleMemberPhotoUpload}
                            />
                            <div className="border-2 border-dashed border-[#8b4513]/20 p-3 text-center text-[10px] uppercase tracking-widest font-bold text-[#8b4513]/60 hover:border-[#d4af37] transition-colors">
                              {memberForm.photo ? 'चित्रं परिवर्तितम् [Change Photo]' : 'चित्रं चिन्वान्तु [Choose Photo]'}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="group">
                    <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">सङ्केतः [Address with Pin Code]</label>
                    <textarea 
                      required 
                      className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] h-24 resize-none transition-colors" 
                      value={memberForm.address || ''}
                      onChange={e => setMemberForm({...memberForm, address: e.target.value})} 
                    />
                  </div>

                  <button 
                    type="submit" 
                    className="w-full bg-[#2c1e12] text-[#d4af37] py-4 text-xs uppercase tracking-widest font-bold hover:bg-[#3d2b1a] transition-all shadow-lg"
                  >
                    {modalType === 'addMember' ? 'पञ्जीकरणं करोतु [Register Member]' : 'परिवर्तनं रक्षतु [Save Changes]'}
                  </button>
                </form>
              )}

              {modalType === 'issueBook' && (
                <form onSubmit={handleIssueBook} className="space-y-8 relative">
                  <div className="absolute -top-10 -right-10 opacity-5 pointer-events-none">
                    <ArrowRightLeft className="w-40 h-40 text-[#8b4513]" />
                  </div>
                  <h3 className="text-3xl font-bold text-[#2c1e12] mb-8 border-b-2 border-[#d4af37]/30 pb-4 flex items-center gap-3">
                    <Clock className="w-8 h-8 text-[#d4af37]" />
                    <span>ग्रन्थ निर्गमनम् [Issue Volume]</span>
                  </h3>
                  <div className="space-y-6">
                    <div className="group">
                      <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">ग्रन्थ पञ्जीकरण सङ्ख्या [Book Registration ID]</label>
                      <div className="relative">
                        <input 
                          type="text"
                          required 
                          placeholder="Enter Book ID (e.g. SMR/CAT/2026/1)"
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-all" 
                          value={issueForm.bookId}
                          onChange={e => setIssueForm({...issueForm, bookId: e.target.value})}
                        />
                        <BookOpen className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b4513]/30 pointer-events-none" />
                      </div>
                      {issueForm.bookId && (
                        <div className="mt-2 text-xs font-bold">
                          {books.find(b => b.id === issueForm.bookId) ? (
                            <span className="text-green-700 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" />
                              Volume Found: {books.find(b => b.id === issueForm.bookId)?.title}
                              {books.find(b => b.id === issueForm.bookId)?.status === 'Borrowed' && (
                                <span className="text-red-600 ml-2">(Already Borrowed!)</span>
                              )}
                            </span>
                          ) : (
                            <span className="text-red-500">Volume not found with this ID</span>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="group">
                      <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">सदस्य सङ्ख्या [Member ID]</label>
                      <div className="relative">
                        <input 
                          type="text"
                          required 
                          placeholder="Enter Member ID (e.g. SMR/MEM/2026/1)"
                          className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-all" 
                          value={issueForm.memberId}
                          onChange={e => setIssueForm({...issueForm, memberId: e.target.value})}
                        />
                        <Users className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8b4513]/30 pointer-events-none" />
                      </div>
                      {issueForm.memberId && (
                        <div className="mt-2 text-xs font-bold">
                          {members.find(m => m.id === issueForm.memberId) ? (
                            <span className="text-green-700 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" />
                              Member Found: {members.find(m => m.id === issueForm.memberId)?.name}
                            </span>
                          ) : (
                            <span className="text-red-500">Member not found with this ID</span>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="group">
                      <label className="block text-[10px] uppercase tracking-widest text-[#8b4513] font-sans font-bold mb-2 group-focus-within:text-[#d4af37] transition-colors">अन्तिमतिथिः [Due Date]</label>
                      <input 
                        type="date" 
                        required 
                        className="w-full bg-white border-2 border-[#8b4513]/10 px-4 py-3 focus:outline-none focus:border-[#d4af37] transition-all" 
                        value={issueForm.dueDate}
                        onChange={e => setIssueForm({...issueForm, dueDate: e.target.value})} 
                      />
                    </div>
                  </div>
                  <button 
                    type="submit" 
                    disabled={!books.find(b => b.id === issueForm.bookId && b.status === 'Available') || !members.find(m => m.id === issueForm.memberId)}
                    className="w-full bg-[#2c1e12] text-[#d4af37] py-5 text-sm uppercase tracking-[0.4em] font-bold shadow-[0_10px_20px_rgba(0,0,0,0.2)] hover:bg-[#3d2b1a] active:scale-[0.98] transition-all border border-[#d4af37]/30 mt-8 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    निर्गमनं पुष्टयतु [Confirm Issue]
                  </button>
                </form>
              )}

              {modalType === 'viewBill' && selectedBill && (
                <div className="space-y-6">
                  <h3 className="text-3xl font-bold text-[#2c1e12] mb-8 border-b-2 border-[#d4af37]/30 pb-4 flex items-center gap-3">
                    <History className="w-8 h-8 text-[#d4af37]" />
                    <span>क्रय-विपत्रम् [Purchase Bill]</span>
                  </h3>
                  <div className="w-full aspect-[3/4] bg-zinc-100 rounded-sm overflow-hidden border-2 border-[#8b4513]/10">
                    {billBlobUrl ? (
                      <object 
                        data={billBlobUrl} 
                        type="application/pdf"
                        className="w-full h-full"
                      >
                        <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center bg-white">
                          <p className="text-[#8b4513] font-bold mb-4">विपत्रं प्रदर्शयितुं न शक्यते [Cannot display bill directly]</p>
                          <a 
                            href={billBlobUrl} 
                            download="bill.pdf"
                            className="bg-[#556b2f] text-white px-6 py-3 rounded-sm font-bold flex items-center gap-2"
                          >
                            <Download className="w-4 h-4" />
                            अधोभारं कृत्वा पश्यन्तु [Download to View]
                          </a>
                        </div>
                      </object>
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#8b4513]/40">
                        <div className="animate-pulse">विपत्रं सज्जीक्रियते [Preparing Bill...]</div>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-4">
                    {billBlobUrl && (
                      <a 
                        href={billBlobUrl} 
                        download="bill.pdf"
                        className="flex-1 bg-[#556b2f] text-white py-4 text-xs uppercase tracking-widest font-bold hover:bg-[#4a5d29] transition-all text-center flex items-center justify-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        अधोभारं करोतु [Download]
                      </a>
                    )}
                    <button 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 bg-[#2c1e12] text-[#d4af37] py-4 text-xs uppercase tracking-widest font-bold hover:bg-[#3d2b1a] transition-all"
                    >
                      पिधानं करोतु [Close]
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      
      {/* Processing Overlay */}
      <AnimatePresence>
        {isProcessing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-[#2c1e12] flex flex-col items-center justify-center text-center p-6"
          >
            <motion.div
              animate={{ 
                rotate: 360,
                scale: [1, 1.1, 1],
              }}
              transition={{ 
                rotate: { duration: 2, repeat: Infinity, ease: "linear" },
                scale: { duration: 1, repeat: Infinity, ease: "easeInOut" }
              }}
              className="mb-8"
            >
              <Scroll className="w-24 h-24 text-[#d4af37]" />
            </motion.div>
            
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <h2 className="text-[#f5f2ed] text-3xl font-serif font-bold tracking-widest mb-4 uppercase">
                {processingType === 'login' && 'प्रवेशः क्रियते [Logging In...]'}
                {processingType === 'logout' && 'निर्गमनं क्रियते [Logging Out...]'}
                {processingType === 'register' && 'पञ्जीकरणं क्रियते [Registering...]'}
                {processingType === 'delete' && 'निष्कासनं क्रियते [Deleting...]'}
                {processingType === 'update' && 'परिवर्तनं क्रियते [Updating...]'}
              </h2>
              <div className="w-48 h-1 bg-[#d4af37]/20 mx-auto rounded-full overflow-hidden">
                <motion.div 
                  initial={{ x: '-100%' }}
                  animate={{ x: '100%' }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                  className="w-full h-full bg-[#d4af37]"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Notification */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[110] bg-[#f5f2ed] border-2 border-[#d4af37] shadow-[0_20px_50px_rgba(0,0,0,0.3)] px-8 py-4 rounded-sm flex items-center gap-4 min-w-[300px]"
          >
            <div className="bg-[#556b2f] p-2 rounded-full">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-[#2c1e12] font-bold text-sm uppercase tracking-wider">{successMessage}</p>
              <p className="text-[#8b4513] text-[10px] uppercase tracking-widest font-medium">सफलं जातम् [Success]</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AIAssistant 
        appState={{
          booksCount: books.length,
          membersCount: members.length,
          categoriesCount: categories.length,
          lastError: lastError,
          currentView: adminTab
        }}
      />

      {/* Footer */}
      <footer className="bg-[#2c1e12] border-t border-[#d4af37]/20 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 justify-between items-center gap-10">
            <div className="flex items-center gap-4">
              <Scroll className="w-8 h-8 text-[#d4af37]" />
              <div>
                <span className="text-[#f5f2ed] text-xl font-serif font-bold tracking-widest block">स्मृतिसंग्रहः</span>
                <span className="text-[#d4af37] text-[10px] uppercase tracking-[0.4em] font-sans font-bold">Smrtisangrahah</span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[#f5f2ed]/40 text-[10px] uppercase tracking-[0.3em] font-sans font-bold mb-2">स्मृतिपथस्य आरम्भः</p>
              <p className="text-[#f5f2ed]/20 text-[10px] uppercase tracking-widest font-sans">Collection of Wisdom &copy; 2026</p>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-[#d4af37]/10 flex justify-center gap-10">
            <a href="#" className="text-[#f5f2ed]/40 hover:text-[#d4af37] text-[10px] uppercase tracking-widest transition-colors font-bold">Privacy</a>
            <a href="#" className="text-[#f5f2ed]/40 hover:text-[#d4af37] text-[10px] uppercase tracking-widest transition-colors font-bold">Terms</a>
            <a href="#" className="text-[#f5f2ed]/40 hover:text-[#d4af37] text-[10px] uppercase tracking-widest transition-colors font-bold">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
